# Librerias externas
from typing import Optional
import sys


def no_existen_en_lista(lista_original: list, sub_lista: list) -> list:
    """Devuelve los elementos de la sub_lista que no existen en la lista original

    :param lista_original: lista con todos los elementos
    :param sub_lista: lista de elementos que se quieren encontrar en la lista original

    :return: la lista de elementos de la sub_lista que no existen en la lista original
    """

    no_existen = []

    for elemento in sub_lista:
        if elemento not in lista_original:
            no_existen.append(elemento)

    return no_existen


def calcula_proporcion(real: int, total: int, decim: Optional[int] = 2) -> float:
    """Calcula la proporcion de una muestra respecto de la población total ajustando al numero de decimales
    especificado.

    :param real: muestra real
    :param total: total de individuos
    :param decim: numero de decimales, por defecto 2

    :return: la proporcion redondeada con el número de decimales especificado"""
    return round((real / total) * 100, ndigits=decim)


def calcula_incremento_porcentual(inicial: float, final: int, decim: Optional[int] = 2) -> float:
    """Calcula el incremento porcentual entre los valores inicial y final, ajunstando el resultado a los
    decimales especificados.

    :param inicial: valor inicial
    :param final: valor final
    :param decim: numero de decimales, por defecto 2

    :return: la proporcion redondeada con el número de decimales especificado"""
    return round(((final - inicial) / inicial) * 100, ndigits=decim)


def calcula_promedio(row: list, decim: Optional[int] = 2, exclude_no_nums: Optional[bool] = True) -> float:
    """Calcula la media del conjunto de datos proporcionado y lo devuelve con el número de decimales especificado.

    :param row: conjunto de datos para los que se quiere calcular la media
    :param decim: numero de decimales, por defecto 2
    :param exclude_no_nums: si es True se hace el cálculo igualmente excluyendo decimales, si es False, se retorna
    False y no se hace el cálculo si se encuentra algún decimal. Por defecto True.

    :return: la media de los datos proporcionados o False si hay datos no numéricos y exlude_no_nums se ha
    especificado como False"""

    muestra = 0
    total = 0
    no_numericos = []

    for dato in row:
        if isinstance(dato, (int, float)):
            muestra += 1
            total += dato
        else:
            if exclude_no_nums is False:
                return False
            else:
                no_numericos.append(dato)

    if len(no_numericos) > 0:
        print(f"Se han detectado {len(no_numericos)} datos no numéricos y se han excluido. Son: {no_numericos}")

    return round((total / muestra), ndigits=decim)

    # Primero evalua si algun dato es no num


def interrumpir():
    print("Alguno de los datos es erroneo y no se puede continuar con la ejecución")
    sys.exit(1)
