# PEC4 - Análisis de datos y creación de un proyecto real

## 1. Descripción
El presente código presenta una aplicación para el análisis de la distribución de licencias, armas de mano y armas
largas en los diferentes estados de EEUU.



## 2. Instalación:
Para la instalación del proyecto lo primero es descomprimir la carpeta pec4_diezgarcia.tar.gz desde una consola de
linux con el comando:
    tar -xzf pec4_diezgarcia.tar.gz

Una vez descomprimido el proyecto, es necesario navegar a la ruta donde se encuentre el proyecto ya descomprimido.
Por ejemplo si se encuentra en la ruta "/PycharmProyects"

Habrá que navegar con:
    cd /PycharmProyects/pec4_diezgarcia/

Una vez dentro, para que el proyecto pueda ejecutarse con normalidad, es necesario instalar las dependencias requeridas
con el comando:
    pip install -r requirements.txt



## 3. Configuración inicial:
Se sirve un fichero config.properties donde se han establecido algunas propiedades globales para la aplicación. Pueden
dejarse como están o modificarse si se desea:

    test_path: indica la ruta donde se encuentran los tests a ejecutar.
    data_path: indica la ruta desde la que se empiezan a localizar los ficheros csv cuando son leídos. Si no
        se especifica ruta absoluta en la función de lectura se buscará desde la ruta definida aquí
    html_path: indica la ruta donde se guardarán los ficheros html generados
    figures_path: indica la ruta donde se guardarán las imágenes generadas.

Además, para poder acceder a la funcionalidad de generación de las imágenes png de los mapas coropléticos, es necesario
disponer del navegador Firefox y de un GeckoDriver compatible. La lista de compatibilidades se puede consultar aquí:

    https://firefox-source-docs.mozilla.org/testing/geckodriver/Support.html

Una vez descargado un driver compatible, debe alojarse en una ruta conocida y después configurarse la siguiente
variable:
    gecko_driver_path: ruta donde se encuentra el driver de gecko utilizado
    auto_detect_firefox: si está en True, el webdriver buscará automáticamente la ruta. Si se especifica en False,
        se buscará el firefox en la ruta definida en firefox_path

Si no se consigue capturar la imagen png correctamente, es posible alterar los parámetros:
    zoom: especifica el zoom inicial
    driver_delay: especifica el tiempo de renderizado del mapa

Para cambiar los parámetros, es posible utilizar primero el comando de visualizacion
    cat config.properties
Y después el de edition. Por ejemplo, para alterar la propiedad test_log:
    sed -i 's/test_log=True/test_log=False/' config.properties



## 4. Ejecución
La función principal main ejecuta secuencialmente todas las instrucciones necesarias para el análisis, y finaliza
elaborando una serie de mapas coropléticos que se guardan tanto en formato png como html para su utilización (ver
apartado configuración).

La manera de ejecutarlo es accediendo desde la terminal a la ruta del proyecto:

    cd /PycharmProyects/pec4_diezgarcia/

Y mediante el comando:

    "python3 main.py"

El proyecto ofrece algunas funciones reutilizables para otros análisis, mientras que otras son específicas para
el conjunto de datos propio.



## 5. Tests
Se han definido en la ruta tests las pruebas unitarias test_commons.py, test_fich.py y test_process.py para la
verificación de las funcionalidades implementadas. Estas pruebas no hacen comprobaciones sobre el conjunto de datos
cargado sino que son pruebas unitarias que comprueban el correcto funcionamiento de cada módulo de forma individual,
asegurando una cobertura del código del 69%.

Desde la ruta origen del proyecto, pueden ejecutarse todos los test con:

        coverage run -m unittest discover -s tests/
        coverage report

Por comodidad se ha deshabilitado la salida de los prints al ejecutar los Tests desde el config.properties, con la
variable:
    tests_log=False

No obstante, si se desea puede habilitarse esta variable para ver la salida.



# 5. Estructura del código
El código se ha estructurado de forma modular en los paquetes:
    -fich, que incluye funciones necesarias para la lectura de ficheros csv, carga, y limpieza de datos
    -process, que se encarga del tema de análisis de datos y manipulación de los mismos
    -graphics, cuya función es pintar la evolución temporal de algunas columnas de datos
    -coropléticos, encargada de generar los mapas de colores de acuerdo a los porcentajes de las variables
    -commons, que incluye algunas funciones comunes como calculos, comprobaciones rutineras...



# 6. Licencia
Este proyecto está licenciado bajo la licencia MIT - ver fichero LICENSE.txt