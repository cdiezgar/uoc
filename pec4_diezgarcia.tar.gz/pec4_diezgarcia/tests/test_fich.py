import io
import sys
import unittest
import config as conf
import pandas as pd

import fich as f


class MyTestCase(unittest.TestCase):

    def setUp(self) -> None:
        if conf.testLog is False:
            sys.stdout = io.StringIO()

    def test_es_csv(self):
        ruta_ok = "Fichero.csv"
        ruta_ko = "Fichero.csvv"
        self.assertEqual(f.es_csv(ruta_ok), True)
        self.assertEqual(f.es_csv(ruta_ko), False)

    def test_existe_csv(self):
        ruta_ok = "data/nics-firearm-background-checks.csv"
        ruta_ko = "data/Ruta.csv"
        self.assertEqual(f.existe_csv(ruta_ok), True)
        self.assertEqual(f.existe_csv(ruta_ko), False)

    def test_es_ruta_absoluta(self):
        ruta_absoluta = "data/nics-firearm-background-checks.csv"
        ruta_relativa = "nics-firearm-background-checks.csv"
        self.assertEqual(f.es_ruta_absoluta(ruta_absoluta), True)
        self.assertEqual(f.es_ruta_absoluta(ruta_relativa), False)

    def test_read_csv(self):
        ruta_ok_relativa = "nics-firearm-background-checks.csv"
        ruta_ok_absoluta = "data/nics-firearm-background-checks.csv"
        no_csv = "nocsv.png"
        no_existe = "noexiste.csv"
        self.assertEqual(f.read_csv(no_csv), False)
        self.assertEqual(f.read_csv(no_existe), False)
        self.assertIsInstance(f.read_csv(ruta_ok_absoluta), pd.DataFrame)
        self.assertEqual(f.read_csv(ruta_ok_absoluta).equals(f.read_csv(ruta_ok_relativa)), True)

    def test_existe_la_columna(self):
        columnas_test = ["Columna 1", "Columna 2", "Columna 3"]
        columna_ok = "Columna 1";
        columna_nok = "Columna inventada"
        self.assertEqual(f.existe_la_columna(columnas_test, columna_ok), True)
        self.assertEqual(f.existe_la_columna(columnas_test, columna_nok), False)

    def test_clean_csv(self):
        df_test = pd.DataFrame({"Columna 1": [1, 2, 3], "Columna 2": [4, 5, 6], "Columna 3": ["a", "b", "c"]})
        cols_ok = ["Columna 1", "Columna 3"]
        cols_nok = ["Columna 1", "Columna inventada"]
        self.assertEqual(f.clean_csv(df_test, cols_nok).columns.tolist(), df_test.columns.tolist())
        self.assertEqual(f.clean_csv(df_test, cols_ok).columns.tolist(), cols_ok)

    def test_rename_cols(self):
        df_test = pd.DataFrame({"Columna 1": [1, 2, 3], "Columna 2": [4, 5, 6], "Columna 3": ["a", "b", "c"]})
        cols_ok = {"Columna 1": "Columna 1 mod", "Columna 2": "Columna 2 mod"}
        cols_nok = {"Columna 1": "Columna 1 mod", "Columna inventada": "Columna inventada mod"}
        cols_esperadas = ["Columna 1 mod", "Columna 2 mod", "Columna 3"]
        self.assertEqual(f.rename_cols(df_test, cols_nok).columns.tolist(), df_test.columns.tolist())
        self.assertEqual(f.rename_cols(df_test, cols_ok).columns.tolist(), cols_esperadas)


suite = unittest.TestSuite()
suite.addTest(unittest.makeSuite(MyTestCase))
unittest.TextTestRunner(verbosity=2).run(suite)
