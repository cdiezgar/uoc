import unittest
import commons as c
import config as conf
import io
import sys


class MyTestCase(unittest.TestCase):

    def setUp(self) -> None:
        if conf.testLog is False:
            sys.stdout = io.StringIO()

    def test_no_existen_en_lista(self):
        l1 = ["Uno", "Dos", "Tres", 3.14, 21, "A"]
        l2 = ["Dos", 257, "Tres", 21, "Cuatro", "A"]
        l_ok = [257, "Cuatro"]
        l_ko = ["Uno", 21, "A"]
        self.assertEqual(c.no_existen_en_lista(l1, l2), l_ok)
        self.assertNotEqual(c.no_existen_en_lista(l1, l2), l_ko)

    def test_calcula_proporcion(self):
        num1 = 10
        num2 = 15
        num3 = 3
        num4 = 9
        precision = 3
        self.assertEqual(c.calcula_proporcion(num1, num2), 66.67)
        self.assertEqual(c.calcula_proporcion(num3, num4, precision), 33.333)

    def test_calcula_incremento_porcentual(self):
        inicial1 = 3
        final1 = 4
        inicial2 = 9
        final2 = 3
        precision = 3
        self.assertEqual(c.calcula_incremento_porcentual(inicial1, final1), 33.33)
        self.assertEqual(c.calcula_incremento_porcentual(inicial2, final2, precision), -66.667)

    def test_calcula_promedio(self):
        lista_numerica = [50, 50, 25, 75, 100, 0]
        lista_no_numerica = [50, 100, 0, "A", 75, 25]
        self.assertEqual(c.calcula_promedio(lista_numerica), 50)
        self.assertEqual(c.calcula_promedio(lista_no_numerica), 50)
        self.assertFalse(c.calcula_promedio(lista_no_numerica, exclude_no_nums=False))


suite = unittest.TestSuite()
suite.addTest(unittest.makeSuite(MyTestCase))
unittest.TextTestRunner(verbosity=2).run(suite)
