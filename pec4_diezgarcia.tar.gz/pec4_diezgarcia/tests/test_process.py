import sys
import unittest
import process as p
import pandas as pd
import io
import config as conf


class MyTestCase(unittest.TestCase):
    def setUp(self) -> None:
        if conf.testLog is False:
            sys.stdout = io.StringIO()

    def test_validar_formato_month(self):
        month_ok = "2023-2"
        month_ko = "mes malo"
        month_ko2 = "2024-03-25"
        self.assertEqual(p.validar_formato_month(month_ok), True)
        self.assertEqual(p.validar_formato_month(month_ko), False)
        self.assertEqual(p.validar_formato_month(month_ko2), False)

    def test_breakdown_date(self):
        df_no_month = pd.DataFrame({"Col1": [1, 2, 3], "Col2": [1, 2, 3]})
        df_ok = pd.DataFrame({"Col1": [1, 2, 3], "month": ["2020-4", "2021-12", "1998-4"]})
        df_ko = pd.DataFrame({"Col1": [1, 2, 3], "month": ["2020-4-22", "2021-12", "NA"]})
        columns_obtenidas_ok = p.breakdown_date(df_ok).columns.tolist()
        columns_obtenidas_ko = p.breakdown_date(df_ok).columns.tolist()
        self.assertFalse(p.breakdown_date(df_no_month))
        self.assertTrue("year" in columns_obtenidas_ok and "month" in columns_obtenidas_ok)
        self.assertEqual(len(p.breakdown_date(df_ok)), len(df_ok))
        self.assertTrue("year" in columns_obtenidas_ko and "month" in columns_obtenidas_ko)
        self.assertTrue(len(p.breakdown_date(df_ko)) < len(df_ok))

    def test_group_by_state_and_year(self):
        df_ok = pd.DataFrame({"state": ["Alabama", "Arizona", "Arizona", "Colorado", "Arizona"],
                              "year": [2022, 2022, 2021, 2019, 2021],
                              "guns": [1, 1, 1, 1, 1]})
        df_ko = pd.DataFrame({"statx": ["Alabama", "Arizona", "Arizona", "Colorado"],
                              "year": [2022, 2022, 2021, 2019],
                              "guns": [1, 1, 1, 1]})
        agrupados_ok = p.group_by_state_and_year(df_ok)
        guns_arizona_2021 = agrupados_ok[
            (agrupados_ok["state"] == "Arizona") & (agrupados_ok["year"] == 2021)]["guns"].iloc[0]
        self.assertFalse(p.group_by_state_and_year(df_ko))
        self.assertEqual(guns_arizona_2021, 2)

    def test_fila_max_columna(self):
        df_ok = pd.DataFrame({"c1": ["a", "b", "c", "d", "e"],
                              "c2": [2000, 2001, 2002, 2003, 2004],
                              "c3": [1, 10, 2, 20, 5]})
        df_ko = pd.DataFrame({"c1": ["a", "b", "c", "d", "e"],
                              "c2": [2000, 2001, 2002, 2003, 2004],
                              "c3": [1, "a", 2, 20, 5]})
        col_ok = "c3"
        col_nok = "c1"
        self.assertFalse(p.fila_max_columna(df_ok, col_nok))
        self.assertFalse(p.fila_max_columna(df_ko, col_ok))
        self.assertEqual(p.fila_max_columna(df_ok, col_ok)["c3"], 20)

    def test_group_by_state(self):
        df_ok = pd.DataFrame({"state": ["Alabama", "Arizona", "Arizona", "Colorado", "Arizona"],
                              "year": [2022, 2022, 2021, 2019, 2021],
                              "guns": [1, 1, 1, 1, 1]})
        agrupados_por_estado_y_year = p.group_by_state_and_year(df_ok)
        agrupados_por_estado = p.group_by_state(agrupados_por_estado_y_year)
        guns_arizona = agrupados_por_estado[
            (agrupados_por_estado["state"] == "Arizona")]["guns"].iloc[0]
        self.assertEqual(guns_arizona, 3)

    def test_clean_states(self):
        df = pd.DataFrame({"state": ["Estado 1", "Estado 2", "Estado 3", "Estado 4", "Estado 5"]})
        df_ko = pd.DataFrame({"statx": ["Estado 1", "Estado 2", "Estado 3", "Estado 4", "Estado 5"]})
        estados_eliminar_ok = ["Estado 2", "Estado 3"]
        estados_eliminar_ko = ["Estado 2", "Estado inventado"]
        self.assertFalse(p.clean_states(df_ko, estados_eliminar_ko))
        self.assertEqual(len(p.clean_states(df, estados_eliminar_ko)), 4)
        self.assertEqual(len(p.clean_states(df, estados_eliminar_ok)), 3)
        self.assertFalse("Estado 2" in (p.clean_states(df, estados_eliminar_ok))["state"].tolist())
        self.assertFalse("Estado 3" in (p.clean_states(df, estados_eliminar_ok))["state"].tolist())

    def test_merge_datasets_on_state(self):
        df1 = pd.DataFrame({"state": ["Uno", "Dos", "Tres"], "num": [1, 2, 3]})
        df2 = pd.DataFrame({"state": ["Uno", "Dos", "Tres"], "type": ["a", "b", "a"]})
        df3 = pd.DataFrame({"estado": ["Uno", "Dos", "Tres"], "type": ["a", "b", "a"]})
        self.assertFalse(p.merge_datasets_on_state(df1, df3))
        self.assertFalse(p.merge_datasets_on_state(df3, df1))
        self.assertTrue("state" in (p.merge_datasets_on_state(df1, df2)).columns.tolist())
        self.assertTrue("num" in (p.merge_datasets_on_state(df1, df2)).columns.tolist())
        self.assertTrue("type" in (p.merge_datasets_on_state(df1, df2)).columns.tolist())

    def test_calculate_relative_values(self):
        df1 = pd.DataFrame({"state": ["A", "B", "C"],
                            "pop_2014": [100, 200, 300],
                            "hand_gun": [10, 10, 100],
                            "long_gun": [20, 50, 150],
                            "permit": [50, 20, 75]})
        df_ko = pd.DataFrame({"state": ["A", "B", "C"],
                              "po_2014": [100, 200, 300],
                              "hand_gun": [10, 40, 100],
                              "longgun": [40, 10, 100],
                              "permit": [100, 10, 40]})
        perc_hand_gun = [10.00, 5.00, 33.33]
        perc_long_gun = [20.00, 25.00, 50]
        perc_permit = [50.00, 10.00, 25.00]
        relatives = p.calculate_relative_values(df1)
        phg = relatives["handgun_perc"]
        plg = relatives["longgun_perc"]
        pp = relatives["permit_perc"]
        self.assertFalse(p.calculate_relative_values(df_ko))
        self.assertEqual(phg.tolist(), perc_hand_gun)
        self.assertEqual(plg.tolist(), perc_long_gun)
        self.assertEqual(pp.tolist(), perc_permit)

    def test_promedio(self):
        df = pd.DataFrame({"A": [25, 75, 50, 50, 100, 0], "B": [10, 20, 10, 10, 20, 20]})
        self.assertFalse(p.promedio(df, "C"))
        self.assertEqual(p.promedio(df, "A"), 50)
        self.assertEqual(p.promedio(df, "B"), 15)

    def test_replace_value_in_column_for_state(self):
        df_ok = pd.DataFrame({"A": [1, 2, 3200, 20, 25],
                              "B": ["Nuevo", "Nuevo", "Modificado", "Modificado", "Nuevo"],
                              "state": ["Uno", "Dos", "Tres", "Cuatro", "Cinco"]})
        df_nok = pd.DataFrame({"A": [1, 2, 3200, 20, 25],
                               "B": ["Nuevo", "Nuevo", "Modificado", "Modificado", "Nuevo"],
                               "status": ["Uno", "Dos", "Tres", "Cuatro", "Cinco"]})
        col_ok = "A"
        col_nok = "D"
        state_ok = "Cuatro"
        state_nok = "Seis"
        df_nuevo = p.replace_value_in_column_for_state(df_ok, state_ok, col_ok, 1000)
        valor_en_nuevo_state_col = df_nuevo.loc[df_nuevo["state"] == state_ok, col_ok].values[0]
        self.assertFalse(p.replace_value_in_column_for_state(df_nok, state_ok, col_ok, 1000))
        self.assertFalse(p.replace_value_in_column_for_state(df_ok, state_ok, col_nok, 1000))
        self.assertFalse(p.replace_value_in_column_for_state(df_ok, state_nok, col_ok, 1000))
        self.assertEqual(valor_en_nuevo_state_col, 1000)


suite = unittest.TestSuite()
suite.addTest(unittest.makeSuite(MyTestCase))
unittest.TextTestRunner(verbosity=2).run(suite)
