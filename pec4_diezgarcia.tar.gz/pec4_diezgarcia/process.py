# Librerias externas

from typing import Union
import pandas as pd
import pandas.api.types as ptypes

# Librerias propias
import fich as f
import commons as c


def breakdown_date(df: pd.DataFrame) -> Union[pd.DataFrame, bool]:
    """Separa la columna month del dataframe proporcionado en 2 columnas: year y monthn

    :param df: el dataframe

    :return: el df pero con las columnas year y month separadas, o False en caso de que no se haya podido separar
    """

    if not f.existe_la_columna(df.columns.tolist(), "month"):
        print("No existe la columna month en el df. No se continuara")
        return False

    # Se construye una columna ficticia valid que indica que se ha podido hacer el split
    df["month_valid"] = df["month"].apply(validar_formato_month)

    # Se pintan los datos no validos para que el usuario sepa cuales son
    meses_no_validos = df[~df["month_valid"]]["month"]

    if len(meses_no_validos) > 0:
        print("Se han encontrado datos invalidos en la columna month y se eliminarán:")
        [print(f"\tMes no valido: {month}") for month in meses_no_validos]

    # Se filtra el df por los datos buenos
    df = df.loc[df["month_valid"]].copy()

    # Se borra la columna ficticia
    df.drop(columns=["month_valid"], inplace=True)

    # Ahora ya se puede hacer split
    df_split = df["month"].str.split("-", expand=True)

    # Se asignan las columnas
    df.loc[:, "year"] = df_split[0].astype(int)
    df.loc[:, "month"] = df_split[1].astype(int)

    # Se pintan las primeras filas
    f.mostrar_info_basica(df, 5)

    return df


def erase_month(df: pd.DataFrame) -> pd.DataFrame:
    """Elimina la columna month del dataframe proporcionado

    :param df: el data frame

    :return: el dataframe sin la columna month
    """

    # Ya se creo en fich una funcion que hace justamente esto pero proporcionando las que se desean mantener
    cols_mantener = [columna for columna in df.columns if columna not in ["month"]]

    # Se elimina la columna month
    df = f.clean_csv(df, cols_mantener)

    # Se muestra la info basic
    f.mostrar_info_basica(df, 5)

    return f.clean_csv(df, cols_mantener)


def group_by_state_and_year(df: pd.DataFrame) -> Union[pd.DataFrame, bool]:
    """Calcula los valores acumulados por año y por estado.

    :param df: el dataframe de los datos

    :return el dataframe con los datos agrupados por año y por estado o False si no se ha podido"""

    # Se verifica que las columnas estado y años existan en el df

    cols = ["year", "state"]

    no_existen = c.no_existen_en_lista(df.columns.tolist(), cols)

    if len(no_existen) > 0:
        print(f"Las columnas {no_existen} no existen y no es posible los datos.")
        return False

    return df.groupby(cols).sum().reset_index()


def group_by_year(df: pd.DataFrame) -> Union[pd.DataFrame, bool]:
    """Calcula los valores acumulados por año y por estado.

    :param df: el dataframe de los datos

    :return el dataframe con los datos agrupados por año o False si no se ha podido"""

    # Se verifica que la columna años existe en el df
    cols = ["year"]

    no_existen = c.no_existen_en_lista(df.columns.tolist(), cols)

    if len(no_existen) > 0:
        print(f"Las columnas {no_existen} no existen y no es posible los datos.")
        return False

    return df.groupby(cols).sum().reset_index()


def group_by_state(df: pd.DataFrame) -> Union[pd.DataFrame, bool]:
    """Calcula los valores acumulados por año y por estado.

    :param df: el dataframe de los datos

    :return el dataframe con los datos agrupados por estado o False si no se ha podido"""

    # Se verifica que la columna años existe en el df
    cols = ["state"]

    no_existen = c.no_existen_en_lista(df.columns.tolist(), cols)

    if len(no_existen) > 0:
        print(f"Las columnas {no_existen} no existen y no es posible agrupar los datos.")
        return False

    df = df.groupby(cols).sum().reset_index()

    f.mostrar_info_basica(df, 5)

    return df


def print_biggest_longguns(df: pd.DataFrame):
    """Pinta un mensaje indicando el estado y el año con el mayor longguns"""

    # Se localiza el la fila con mayor valor en longuns
    fila = fila_max_columna(df, "long_gun")

    if fila is False:
        print("No ha podido obtenerse el máximo de la columna long_gun")
    else:
        print(f"El mayor número de armas largas se ha registrado en el estado de {fila['state']} "
              f"en el año {fila['year']} y ha sido de {fila['long_gun']} armas largas")


def print_biggest_handguns(df: pd.DataFrame):
    """Pinta un mensaje indicando el estado y el año con el mayor handguns"""

    # Se localiza el la fila con mayor valor en longuns
    fila = fila_max_columna(df, "hand_gun")

    if fila is False:
        print("No ha podido obtenerse el máximo de la columna hand_gun")
    else:
        print(f"El mayor número de armas cortas se ha registrado en el estado de {fila['state']} "
              f"en el año {fila['year']} y ha sido de {fila['hand_gun']} armas cortas")


def merge_datasets_on_state(df1: pd.DataFrame, df2: pd.DataFrame) -> Union[bool, pd.DataFrame]:
    """Fusiona 2 datasets por la columna state

    :param df1: Conjunto de datos 1
    :param df2: Conjunto de datos 2

    :return: Un nuevo dataframe resultado de la fusión de los 2 previos en la columna state o False si no se puede
    fusionar porque no existe la columna estado"""

    cols = ["state"]

    no_existen1 = c.no_existen_en_lista(df1.columns.tolist(), cols)
    no_existen2 = c.no_existen_en_lista(df2.columns.tolist(), cols)

    if len(no_existen1) > 0 or len(no_existen2) > 0:
        print(f"La columna estado no existe en alguno de los dataframes proporcionados y no es posible la fusión")
        return False

    df = pd.merge(df1, df2, on="state", how="inner")

    f.mostrar_info_basica(df, 5)

    return df


def calculate_relative_values(df: pd.DataFrame) -> pd.DataFrame:
    """Calcula las proporciones de las columnas permit, long_gun y hand_gun respecto de la poblacion total de
    cada uno de los estados

    :param df: el dataframe con los datos mergeados de los conjuntos de datos

    :return: el dataframe incorporando las columnas con la proporcion"""

    cols = ["permit", "hand_gun", "long_gun", "pop_2014"]

    no_existen = c.no_existen_en_lista(df.columns.tolist(), cols)
    if len(no_existen) > 0:
        print(f"Las columnas {no_existen} no existe en alguno de los dataframes proporcionados y "
              f"no es continuar")
        return False

    df["permit_perc"] = c.calcula_proporcion(df["permit"], df["pop_2014"])
    df["longgun_perc"] = c.calcula_proporcion(df["long_gun"], df["pop_2014"])
    df["handgun_perc"] = c.calcula_proporcion(df["hand_gun"], df["pop_2014"])

    f.mostrar_info_basica(df, 5)

    return df


def clean_states(df: pd.DataFrame, states: list) -> Union[pd.DataFrame, bool]:
    """Limpia los estados indicados del dataframe proporcionado

    :param df: el dataframe original
    :param states: listado con los estados que se quieren eliminar del df o False en caso contrario"""

    col_state = "state"

    # Se valida que exista la columna state en el df proporcionado
    if f.existe_la_columna(df.columns.tolist(), col_state) is False:
        print(f"No existe la columna {col_state} en el df proporcionado")
        return False

    # Se almacenan los estados encontrados en el df
    estados_en_df = df[col_state].tolist()
    print(f"Estados antes de eliminar: {len(estados_en_df)}")

    # Se recorren los estados a borrar, se comprueba si tienen datos y se borran
    for state in states:
        if state in estados_en_df:
            df = df[df[col_state] != state]
        else:
            print(f"El estado {state} no tiene datos por lo que no es necesario eliminarlo")

    print(f"Estados después de eliminar: {len(df[col_state].tolist())}")

    return df


def promedio(df: pd.DataFrame, col: str) -> Union[float, bool]:
    """Calcula el promedio de la columna especificada del conjunto de datos proporcionado, lo pinta y lo devuelve.

    :param df: el dataframe con los datos
    :param col: la columna de la que quiere mostrarse el promedio

    :return: el promedio de la columna especificada y False en caso de que no pueda calcularse"""

    if f.existe_la_columna(df.columns.tolist(), col) is False:
        print(f"No existe la columna {col} en el df proporcionado")
        return False

    # Si se obtienen datos erroneos (no numéricos) se ignoran
    promedio_col = c.calcula_promedio(df[col].tolist())
    if promedio_col is False:
        return False

    print(f"Promedio de {col}: {promedio_col}")

    return promedio_col


def info_estado(df: pd.DataFrame, states: list):
    """Muestra toda la información del dataframe para el estado indicado y si no existe muestra un mensaje.

    :param df: el dataframe con los datos.
    :param states: lista de estados de los que se quiere conocer los datos
    """

    col = "state"
    states_ok = []

    # Si no existe la columna pintamos un mensaje
    if f.existe_la_columna(df.columns.tolist(), col) is False:
        print(f"No existe la columna {col} en el df proporcionado")
    else:
        df_estados = pd.DataFrame(columns=df.columns)

        # Se recorre cada estado de los que se quiera tener informacion
        for state in states:

            # Si existe en el df se saca la informacion
            if state in df["state"].values:
                states_ok.append(state)
                df_estado = df[df[col] == state]
                df_estados = pd.concat([df_estados, df_estado])

            # Sino se avisa
            else:
                print(f"El estado {state} no ha sido encontrado en el df proporcionado")
        print(f"La información de los estados {states_ok} es:\n {df_estados}")


def replace_value_in_column_for_state(df: pd.DataFrame, state: str, column: str, newval: any) -> pd.DataFrame:
    """Reemplaza un valor en la columna especificada para el estado indicado.

    :param df: el dataframe
    :param state: el estado del que se quiere reemplazar el valor
    :param column: la columna donde se encuentra el valor a reemplazar
    :param newval: el nuevo valor para la columna indicada

    :return el dataframe con el valor reemplazado para el estado y columna indicadas o False si no se puede
    reemplazar por alguna razón"""

    cols = ["state", column]
    cols_ok = True

    # La columna indicada debe existir en el DF
    for col in cols:
        if f.existe_la_columna(df.columns.tolist(), col) is False:
            print(f"No existe la columna {col} en el df proporcionado")
            cols_ok = False

    if cols_ok is False:
        print(f"No se puede reemplazar porque no existe alguna columna")
        return False

    # El estado indicado debe existir en el DF
    if state not in df["state"].values:
        print(f"El estado {state} no se encuentra en el df y no es posible reemplazar")
        return False

    # Se omite comparacion del tipo de dato
    print(f"Dato reemplazado: {df.loc[df['state'] == state, column].values[0]} por {newval} en el estado de"
          f" {state} y para la columna {column}.")
    df.loc[df["state"] == state, column] = newval

    return df


def validar_formato_month(month: str) -> bool:
    """Valida que el dato proporcionado sea valido y pueda splitearse

    :param month: el mes

    :returns True si ha podido splitear y False en caso contrario
    """

    try:
        year, month = month.split("-")
        return True
    except Exception as e:
        return False


def fila_max_columna(df: pd.DataFrame, col: str) -> Union[pd.Series, bool]:
    """Localiza el indice de la fila que se corresponde con el mayor valor para la columna especificada

    :param df: el data frame
    :param col: la columna

    :return el indice asociado a la fila con mayor valor en la columna especificada, o False si no puede localizarse
    """

    # Primero tiene que existir la columna:

    if not f.existe_la_columna(df.columns.tolist(), col):
        print(f"La columna {col} no existe en el dataframe")
        return False

    # Se valida que la columna tenga datos enteros porque sino fallara la localizacion del maximo
    if not ptypes.is_numeric_dtype(df[col]):
        print(f"La columna {col} no es numerica")
        return False

    # Si se cumple lo anterior puede localizarse el maximo
    return df.loc[df[col].idxmax()]
