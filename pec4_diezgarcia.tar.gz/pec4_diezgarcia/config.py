# Carga las variables de configuracion necesarias para el funcionamiento de la aplicación
import configparser
import os

config = configparser.ConfigParser()

config.read("config.properties")

testsPath = config.get("PATHS", "test_path")
htmlPath = config.get("PATHS", "html_path")
dataPath = config.get("PATHS", "data_path")
figuresPath = config.get("PATHS", "figures_path")
driverPath = config.get("PATHS", "gecko_driver_path")
firefoxPath = config.get("PATHS", "firefox_path")
driverDelay = config.get("COROPLETICOS", "driver_delay")
mapZoom = config.get("COROPLETICOS", "zoom")
url_maps = config.get("COROPLETICOS", "folium_example_url")
key_on_coro = config.get("COROPLETICOS", "key_on")

autoFirefox = config.get("BOOLS", "auto_detect_firefox") == "True"
testLog = config.get("BOOLS", "tests_log") == "True"

# Se crean los directorios necesarios para que si o si existan a la hora de ejecutar la app
if not os.path.exists(htmlPath):
    os.makedirs(htmlPath)

if not os.path.exists(dataPath):
    os.makedirs(dataPath)

if not os.path.exists(figuresPath):
    os.makedirs(figuresPath)

if not os.path.exists(driverPath):
    os.makedirs(driverPath)





