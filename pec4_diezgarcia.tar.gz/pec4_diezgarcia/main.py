# Librerias propias
import fich as f
import commons as c
import process as p
import graphics as g
import coropleticos as cor
import config as conf

print("\nEjercicio 1. Lectura y limpieza de datos.\n")

print("\nEjercicio 1.1")

print(f"Introduce la ruta del csv con los datos. Si solo se especifica el nombre, entonces se buscará el fichero en: "
      f"{conf.dataPath}. El fichero debe tener almenos las columnas 'month', 'state', 'permit', 'handgun' y"
      f" 'long_gun'")

csvEstados = input()

df_nics = f.read_csv(csvEstados)

if df_nics is False:
    c.interrumpir()

print("\nEjercicio 1.2")
df_nics = f.clean_csv(df_nics, ["month", "state", "permit", "handgun", "long_gun"])

print("\nEjercicio 1.3")
# La columna long_gun ya existia. Podría referise a hand_gun. Se pasa ambas por unificar
df_nics = f.rename_cols(df_nics, {"longgun": "long_gun", "handgun": "hand_gun"})

print("\nEjercicio 2. Procesamiento de datos. \n")

print("\nEjercicio 2.1")
df_nics = p.breakdown_date(df_nics)
if df_nics is False:
    c.interrumpir()

print("\nEjercicio 2.2")
df_nics = p.erase_month(df_nics)

print("\nEjercicio 3. Agrupamiento de datos. \n")

print("\nEjercicio 3.1")
df_per_year_state = p.group_by_state_and_year(df_nics)
if df_per_year_state is False:
    c.interrumpir()

print("\nEjercicio 3.2")
p.print_biggest_longguns(df_per_year_state)

print("\nEjercicio 3.3")
p.print_biggest_handguns(df_per_year_state)

print("\nEjercicio 4. Agrupamiento de datos.\n")

print("\nEjercicio 4.1")

g.time_evolution(df_nics)

print("\nEjercicio 4.2")

print("En vista de los resultados, parece apreciarse una correlación positiva entre el número de licencias"
      " y la posesión de armas.\n"
      "Esta tendencia ha sido ascentente hasta aproximadamente 2017 momento en el"
      " que se observa un pico y posteriormente la tendencia ha sido descendente.\n"
      "Respecto a la pandemia, parece durante el tiempo de confinamiento ha disminuido el número de licencias"
      " así como la tenencia de ambas de los 2 tipos.\n"
      "En los próximos años, podría esperarse una estabilización tanto de la tenencia como el número de licencias,\n"
      "aunque por otra parte, también podría incrementarse de nuevo ya que justo coincide con el periódo de pandemia"
      " y no existen datos a posteriori \ny esa bajada podría ser un \"valle\" provocado por la pandemia")

print("\nEjercicio 5. Análisis de los estados.\n")

print("\nEjercicio 5.1")
df_per_state = p.group_by_state(df_per_year_state)
if df_per_state is False:
    c.interrumpir()

print("\nEjercicio 5.2")
states_to_remove = ["Guam", "Mariana Islands", "Puerto Rico", "Virgin Islands"]
df_per_state_without_states = p.clean_states(df_per_state, states_to_remove)
if df_per_state_without_states is False:
    c.interrumpir()

print("\nEjercicio 5.3")

print(f"Introduce el estado con las poblaciones absolutas de los estados. Si solo se introduce el nombre, se buscará"
      f" en  {conf.dataPath}. Este fichero debe tener las columnas 'state' y 'pop2014'")

csvPop = input()

df_populations = f.read_csv(csvPop)
df_merged = p.merge_datasets_on_state(df_per_state_without_states, df_populations)
if df_merged is False:
    c.interrumpir()

print("\nEjercicio 5.4")
df_relative = p.calculate_relative_values(df_merged)
if df_relative is False:
    c.interrumpir()

print("\nEjercicio 5.5")

print("\nEjercicio 5.5.1")

promedio_permit_perc = p.promedio(df_relative, "permit_perc")
if promedio_permit_perc is False:
    c.interrumpir()

print("\nEjercicio 5.5.2")
# Se muestran también otro par de estados para ver diferencias significativas
p.info_estado(df_relative, ["Alabama", "Kentucky", "Ohio"])
print(f"Se muestra un valor exageradamente alto (>> 100%) para el porcentaje de Kentucky. Se reemplaza el valor"
      f" por el promedio {promedio_permit_perc} de todos los estados")

print("\nEjercicio 5.5.3")
df_kentucky_ok = p.replace_value_in_column_for_state(df_relative, "Kentucky", "permit_perc", promedio_permit_perc)
if df_kentucky_ok is False:
    c.interrumpir()

print("\nEjercicio 5.5.4")
promedio_permit_perc_final = p.promedio(df_kentucky_ok, "permit_perc")
diferencia_porcentual = c.calcula_incremento_porcentual(promedio_permit_perc, promedio_permit_perc_final)
print(f"La diferencia porcentual es de {diferencia_porcentual}%")

print("\nEjercicio 5.5.5")
print(f"Como se observa, la diferencia porcentual es de casi el 40%, lo que refleja la importancia de un"
      f" correcto preprocesamiento de datos para evitar que los datos estén\n'sesgados' o  que presenten "
      f"distorsiones que empobrezcan o vuelvan inservibles los resultados obtenidos.")

print("\nEjercicio 6. Mapas coropléticos.\n")
htmls = cor.genera_mapa_coropletico(df_relative, ["permit_perc", "handgun_perc", "longgun_perc"])
if htmls is False:
    c.interrumpir()

cor.genera_imagenes_mapas_coropleticos(htmls)
