# Librerias externas
import commons as c
import pandas as pd
import os
from typing import Union

# Librerias propias
import config as conf


def read_csv(ruta: str) -> Union[pd.DataFrame, bool]:
    """Permite la lectura del fichero CSV que se proporcione y muestra la estructura
    básica de los datos así como las 5 primeras filas

    Parámetros:
    ---ruta: ruta en la que se encuentra el fichero. Puede ser relativa o absoluta.
    Si la ruta es relativa busca el fichero en la ruta configurada en config.properties

    Devuelve: Un dataframe con los datos leidos o false en caso de que no se encuentre la ruta"""

    # Si no es un csv valido advertimos al usuario y no seguimos
    if not es_csv(ruta):
        print("La extensión no es .csv")
        return False
    else:
        # Si contiene el caracter / se asume ruta absoluta y sino relativa
        ruta = ruta if es_ruta_absoluta(ruta) else f"{conf.dataPath}/{ruta}"

        # Si existe el csv se lee
        if not existe_csv(ruta):
            print("No existe el fichero")
            return False

        else:
            df = pd.read_csv(ruta)
            mostrar_info_basica(df, 5)
            return df


def clean_csv(df: pd.DataFrame, cols: list) -> pd.DataFrame:
    """Elimina todas las columnas del dataframe salvo las que se especifiquen y muestra por pantalla
    las columnas del df resultante

    Parámetros:
    ---df: el dataframe original
    ---cols: las columnas que se mantienen

    Devuelve:
    Un dataframe que solo tiene las columnas especificadas o el dataframe original si no existe alguna de las cols
    """

    columnas_df = df.columns.tolist()

    columnas_no_existen = c.no_existen_en_lista(columnas_df, cols)

    # Solo se limpian si existen
    if len(columnas_no_existen) == 0:
        # Se eliminan justo las que no esten en cols
        cols_eliminar = [columna for columna in columnas_df if columna not in cols]
        df.drop(columns=cols_eliminar, inplace=True)
        print(f"Tras la eliminación de las columnas resulta el df con las columnas: {df.columns}")

    else:
        print(f"Las siguientes columnas no existen en los datos: {columnas_no_existen}, se devuelve el df original")

    return df


def rename_cols(df: pd.DataFrame, cols: dict) -> pd.DataFrame:
    """Modifica el nombre de las columnas especificadas dentro del dataframe si las columnas existen

    :param df: el dataframe
    :param cols: diccionario con las columnas que se pretenden modificar

    :return: el dataframe con las columnas modificadas o el df original si no existe la columna

    Ejemplo: rename_cols(df, {"Columna 1", "Columna 1 mod"}) devolvera df con la columna "Columna 1 mod"
    en lugar de "Columna 1"
    """

    # Primero vemos si existe la columna
    columnas_no_existen = c.no_existen_en_lista(df.columns.tolist(), cols.keys())

    columnas_ok = {}

    for k, v in cols.items():
        if k not in columnas_no_existen:
            columnas_ok[k] = v

    if len(columnas_no_existen) > 0:
        print(f"Las siguientes columnas no existen en los datos y no se pueden renombrar: {columnas_no_existen}")

    if len(columnas_ok) > 0:
        df.rename(columns=columnas_ok, inplace=True)
        print(f"Las siguientes columnas se han renombrado correctamente {columnas_ok}")

    return df


def es_ruta_absoluta(ruta: str) -> bool:
    """Comprueba si la ruta proporcionada es absoluta o relativa basándose en el criterio
    de contención del caracter /

    Parámetros:
    ---ruta: ruta que pretende comprobarse

    Devuelve: true si es absoluta y false si es relativa"""

    return ruta.__contains__("/")


def es_csv(ruta: str) -> bool:
    """Valida que la ruta indicada termine en extensión .csv
    Parámetros:
    ---ruta: ruta donde se encuentra el csv
    Devuelve: true si el fichero tiene extensión .csv y false en caso contrario
    """

    return ruta.endswith(".csv")


def existe_csv(ruta: str) -> bool:
    """Valida que exista el fichero en la ruta indicada
    Parámetros:
    ---ruta: ruta donde se encuentra el csv
    Devuelve: true si la ruta existe y false en caso contrario
    """

    return os.path.exists(ruta)


def mostrar_info_basica(df: pd.DataFrame, filas: int):
    """Muestra la información basica del fichero csv proporcionado en forma de dataframe

    Parametros:
    ---df: el dataframe
    ---filas: el numero de filas a mostrar
    """

    # Se muestra la estructura y las 5 primeras filas
    print("Estructura básica:\n {}".format(df.dtypes))
    print("5 Primeras filas:\n {}".format(df.head(n=filas)))


def existe_la_columna(cols: list, col: str) -> bool:
    """Comprueba que la columna indicada exista en el listado de columnas

    Parámetros:
    ---col: columna para la que se quiere comprobar existencia
    ---cols: lista de columnas

    Devuelve:
    Un dataframe que solo tiene las columnas especificadas
    """
    return col in cols

