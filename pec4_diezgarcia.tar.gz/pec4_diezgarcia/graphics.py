# Librerias externas
import pandas as pd
import matplotlib.pyplot as plt
import pandas.api.types as ptypes

# Librerias propias
import fich as f
import process as p
import config as conf


def time_evolution(df: pd.DataFrame):
    """Pinta la evolucion de los datos a lo largo del tiempo.

    :param df: el dataframe con los datos"""

    # Primero hay que agrupar los datos por año
    per_year = p.group_by_year(df)

    # Se definen las columnas
    datos = {"permit": "Permitidas", "hand_gun": "Armas de mano", "long_gun": "Armas de largo alcance"}

    # Se pinta
    dibuja_evolucion_temporal(per_year, datos)


def dibuja_evolucion_temporal(df: pd.DataFrame, datos: dict):
    """Pinta la evolucion temporal de los datos proporcionados en el diccionario.

    :param df: el dataframe original
    :param datos: diccionario de datos a pintar con su label correspondiente. La key es la columna y el value
    es el label
    """

    # Se crea el área para el gráfico
    plt.figure(figsize=(10, 6))

    # Se recorren los datos que se quieren pintar
    for k, v in datos.items():
        if f.existe_la_columna(df.columns.tolist(), k) and ptypes.is_numeric_dtype(df[k]):
            plt.plot(df["year"], df[k], label=v)
        else:
            print(f"La columna {k} no existe en el dataframe proporcionado y se omitirá en el gráfico")

    # Se añade el titulo al gráfico y los títulos de los ejes. Para el titulo se necesitan los labels
    labels = ", ".join([val for val in datos.values()])
    plt.xlabel("Año")
    plt.ylabel("Número")
    plt.title(f"Evolución de {labels}")
    plt.legend()

    # Se guarda el gráfico
    ruta = f"{conf.figuresPath}/{labels.replace(', ', '_')}.png"

    plt.savefig(ruta)

    print(f"Imagen guardada en {ruta}")
