# Librerias externas
from typing import Union
from PIL import Image
from selenium import webdriver
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.firefox.options import Options
import time
import folium
import pandas as pd
import io
import os

# Librerias propias
import fich as f
import config as conf

def genera_mapa_coropletico(df: pd.DataFrame, cols: list) -> Union[list, bool]:
    """Genera un mapa coropletico en la ruta html/ basandose en el df proporcionado y para las columnas indicadas.
    Si no puede generarlo pinta un mensaje. Si no existe alguna columna proporcionada, se advierte y se generan
    los mapas de las columnas existentes.

    Genera mapas interactivos en la ruta html/ y mapas estaticos en png en la ruta figures/

    :param df: el conjunto de datos
    :param cols: lista con las columnas para las que se quieren generar los mapas

    :return False si no existe la columna state y un listado de los mapas del tipo folium.Map
    """

    # Se valida que exista state en el df
    col_state = "state"
    if f.existe_la_columna(df.columns.tolist(), "state") is False:
        print(f"No existe la columna state en el df proporcionado y no puede generarse ningún mapa")
        return False

    # Se cambia la key a properties.name basandonos en el us-states.json. Ahí es donde viene el nombre del estado.
    state_geo = f"{conf.url_maps}/us-states.json"
    maps = []

    for col in cols:
        if f.existe_la_columna(df.columns.tolist(), col) is False:
            print(f"No existe la columna {col} en el df proporcionado y no puede generarse el mapa")
        else:
            mapa = folium.Map(location=[40, -95], zoom_start=conf.mapZoom)
            folium.Choropleth(
                geo_data=state_geo,
                name="choropleth",
                data=df,
                columns=[col_state, col],
                key_on=conf.key_on_coro,
                fill_color="YlGn",
                fill_opacity=0.7,
                line_opacity=.1,
                legend_name=col,
            ).add_to(mapa)
            folium.LayerControl().add_to(mapa)
            name = f"{col}-with-folium"
            ruta = f"{conf.htmlPath}/{name}.html"
            mapa.save(ruta)
            print(f"Mapa generado: {ruta}")
            maps.append(ruta)

    return maps


def genera_imagenes_mapas_coropleticos(htmls: list):
    """Genera los png asociados a cada mapa coropletico en base al listado de mapas proporcionado.

    :param htmls: listado de mapas coropleticos del tipo folium.Map
    """
    # Instancia del driver

    counter = 0
    for index, html in enumerate(htmls):
        if str.endswith(html, ".html"):
            try:
                # Creacion de la imagen
                img_data = generate_png_from_map(html, delay=2)
                img = Image.open(io.BytesIO(img_data))

                # Cambio del nombre a .png
                img_name = str(html).replace("html", "").replace("/", "") + "png"
                img.save(f'{conf.figuresPath}/{img_name}')
                print(f"Imagen generada: figures/{img_name}")
                counter += 1

            except Exception as e:
                print(f"Problema relacionado con el driver al generar la imagen: {e}")
        else:
            print(f"{html} no es una ruta valida para generar el mapa")

    if counter == 0:
        print("No se ha generado ninguna imagen. Revisar que los datos introducidos son correctos")


# Función para generar el PNG desde el mapa folium
def generate_png_from_map(html: str, delay=5):

    service = Service(executable_path=conf.driverPath)
    options = Options()
    options.add_argument("--headless")

    # Si se especifica un firefox se guarda el location para que se ejecute con ese
    if conf.autoFirefox is False:
        options.binary_location = conf.firefoxPath

    # Iniciar el driver de Firefox
    driver = webdriver.Firefox(options=options, service=service)

    # Renderizar el HTML del mapa
    try:
        # Verificar que el archivo HTML existe
        if not os.path.exists(html):
            raise FileNotFoundError(f"El archivo {html} no existe.")

        # Depurar la ruta del archivo HTML
        print(f"Using HTML file at: {html}")

        # Cargar el archivo HTML en el navegador
        file_url = f"file://{os.path.abspath(html)}"
        print(f"Loading file in browser from: {file_url}")
        driver.get(file_url)
        driver.set_window_size(1920, 1080)
        time.sleep(delay)  # Aumentar el tiempo de espera si es necesario

        # Tomar la captura de pantalla del mapa
        png = driver.get_screenshot_as_png()

    finally:
        driver.quit()

    return png
